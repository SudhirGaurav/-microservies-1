package com.sudhirudemystudy.microservices.currencyexchnageservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyExchnageServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyExchnageServiceApplication.class, args);
	}

}
